// Service worker: the only place with cross-origin fetch permission.
// Content scripts MUST route API calls through here via chrome.runtime messages
// because Marketplace / eBay pages have strict CSP that blocks direct fetch().

const DEFAULT_API_URL = 'https://faircheck-backend-production.up.railway.app'

// Hosts we shipped as defaults in earlier versions that either never existed
// or no longer resolve. If a user's chrome.storage.sync still has one of these
// from an older install, we quietly migrate them to the live default so they
// don't stay stuck on a dead URL.
const DEAD_HOSTS = new Set([
  'api.faivri.com',
  'api.faircheck.com',
  'faivri.com',
])

function isDeadUrl(raw) {
  try {
    const host = new URL(raw).host.toLowerCase()
    return DEAD_HOSTS.has(host)
  } catch {
    return true
  }
}

async function getApiUrl() {
  try {
    const { apiUrl } = await chrome.storage.sync.get(['apiUrl'])
    if (typeof apiUrl !== 'string' || !apiUrl.trim()) return DEFAULT_API_URL
    if (isDeadUrl(apiUrl)) {
      // Migrate and clear — next call picks up the current default.
      await chrome.storage.sync.remove('apiUrl').catch(() => {})
      return DEFAULT_API_URL
    }
    return apiUrl.trim()
  } catch {
    return DEFAULT_API_URL
  }
}

// ─── MV3 service worker keepalive ─────────────────────────────────────
// MV3 service workers can be killed while a long fetch is in flight, which
// drops the sendResponse callback and leaves the content script spinning
// forever. The well-known workaround: call a tiny chrome.* API on a timer
// while any request is pending so Chrome keeps the worker alive.
let inflightRequests = 0
let keepaliveTimer = null

function startKeepalive() {
  if (keepaliveTimer) return
  keepaliveTimer = setInterval(() => {
    // Any async chrome.* call resets the idle timer. We don't need the result.
    chrome.runtime.getPlatformInfo().catch(() => {})
  }, 20000)
}

function stopKeepalive() {
  if (keepaliveTimer) {
    clearInterval(keepaliveTimer)
    keepaliveTimer = null
  }
}

// AbortController-based timeout — so if a request genuinely hangs upstream,
// we surface an error instead of leaving the content script waiting.
const REQUEST_TIMEOUT_MS = 75000

async function apiRequest(path, init = {}) {
  inflightRequests += 1
  startKeepalive()

  const base = await getApiUrl()
  const url = `${base.replace(/\/$/, '')}${path}`
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)

  try {
    const res = await fetch(url, {
      ...init,
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        'X-Faivri-Source': 'extension',
        ...(init.headers || {}),
      },
    })

    const requestId = res.headers.get('X-Request-ID')
    let body = null
    try { body = await res.json() } catch { /* non-JSON */ }

    if (!res.ok) {
      const detail = body && typeof body.detail === 'string'
        ? body.detail
        : `API error ${res.status}`
      // Pass the structured detail body through so the overlay can render
      // a bespoke UI for 402 (quota exhausted + Boost Pack CTA) instead of
      // a generic error banner.
      const quotaDetail = res.status === 402 && body && typeof body.detail === 'object'
        ? body.detail
        : null
      return { ok: false, status: res.status, error: detail, quotaDetail, requestId }
    }
    return { ok: true, status: res.status, data: body, requestId }
  } catch (networkErr) {
    const aborted = networkErr && networkErr.name === 'AbortError'
    return {
      ok: false,
      status: 0,
      error: aborted
        ? `Faivri took too long to respond (>${Math.round(REQUEST_TIMEOUT_MS / 1000)}s). Try again — servers may be under load.`
        : `Can't reach Faivri API (${networkErr && networkErr.message || 'network error'}). Check your internet connection.`,
      requestId: null,
    }
  } finally {
    clearTimeout(timeoutId)
    inflightRequests -= 1
    if (inflightRequests <= 0) {
      inflightRequests = 0
      stopKeepalive()
    }
  }
}

// ─── SPA-navigation injection ─────────────────────────────────────────
// Content scripts declared in manifest only fire on the INITIAL page load
// for a matching URL. If a user navigates to /marketplace/item/... via FB's
// client-side router (no full reload), nothing fires. We listen for the
// history state update and inject the scripts ourselves.
const MARKETPLACE_URL_RE = /^https:\/\/[a-z0-9.-]*facebook\.com\/marketplace\//i
const EBAY_URL_RE = /^https:\/\/[a-z0-9.-]*ebay\.com\/itm\//i

async function injectIfMatching(tabId, url) {
  const isMarketplace = MARKETPLACE_URL_RE.test(url)
  const isEbay = EBAY_URL_RE.test(url)
  if (!isMarketplace && !isEbay) return

  const extractor = isMarketplace ? 'content/extract-marketplace.js' : 'content/extract-ebay.js'
  try {
    // Load order matters: the extractor must define window.__FAIVRI_IS_LISTING
    // BEFORE overlay.js runs its initial refreshVisibility(). If overlay runs
    // first, isListing() returns false, the pill stays hidden, and the user
    // sees nothing on an otherwise-valid listing page.
    await chrome.scripting.insertCSS({
      target: { tabId },
      files: ['content/overlay.css'],
    })
    await chrome.scripting.executeScript({
      target: { tabId },
      files: [extractor, 'content/overlay.js'],
    })
  } catch (err) {
    // Some pages (login, chrome:// fallback) can't be injected — safe to ignore.
  }
}

if (chrome.webNavigation && chrome.webNavigation.onHistoryStateUpdated) {
  chrome.webNavigation.onHistoryStateUpdated.addListener((details) => {
    if (details.frameId !== 0) return
    injectIfMatching(details.tabId, details.url)
  })
}

// On first install / update, clear any dead default URL from storage so new
// tabs pick up the live backend without needing a manual popup save.
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(['apiUrl']).then(({ apiUrl }) => {
    if (typeof apiUrl === 'string' && isDeadUrl(apiUrl)) {
      chrome.storage.sync.remove('apiUrl').catch(() => {})
    }
  }).catch(() => {})
})

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return

  if (msg.type === 'FAIVRI_ANALYZE') {
    apiRequest('/api/v1/analyze', {
      method: 'POST',
      body: JSON.stringify(msg.payload || {}),
    }).then(sendResponse)
    return true // keep sendResponse alive for async reply
  }

  if (msg.type === 'FAIVRI_BOOST_CHECKOUT') {
    apiRequest('/api/v1/usage/boost/checkout', { method: 'GET' }).then(sendResponse)
    return true
  }

  if (msg.type === 'FAIVRI_NEGOTIATE') {
    apiRequest('/api/v1/negotiate', {
      method: 'POST',
      body: JSON.stringify({ query_id: msg.queryId }),
    }).then(sendResponse)
    return true
  }

  if (msg.type === 'FAIVRI_CHAT') {
    apiRequest('/api/v1/negotiate/chat', {
      method: 'POST',
      body: JSON.stringify(msg.payload || {}),
    }).then(sendResponse)
    return true
  }

  if (msg.type === 'FAIVRI_CHAT_HISTORY') {
    const { queryId, sessionId } = msg
    if (!queryId || !sessionId) {
      sendResponse({ ok: false, status: 400, error: 'Missing queryId or sessionId.' })
      return false
    }
    apiRequest(
      `/api/v1/negotiate/chat/${encodeURIComponent(queryId)}/${encodeURIComponent(sessionId)}`,
      { method: 'GET' },
    ).then(sendResponse)
    return true
  }

  // ── Extension Pro endpoints ─────────────────────────────────────────────
  if (msg.type === 'FAIVRI_SELLER_RISK') {
    apiRequest('/api/v1/extension/seller-risk', {
      method: 'POST',
      body: JSON.stringify(msg.payload || {}),
    }).then(sendResponse)
    return true
  }

  if (msg.type === 'FAIVRI_REPLY_COACH') {
    apiRequest('/api/v1/extension/reply-coach', {
      method: 'POST',
      body: JSON.stringify(msg.payload || {}),
    }).then(sendResponse)
    return true
  }

  if (msg.type === 'FAIVRI_WATCH_CREATE') {
    apiRequest('/api/v1/extension/listing-watch', {
      method: 'POST',
      body: JSON.stringify(msg.payload || {}),
    }).then(sendResponse)
    return true
  }

  if (msg.type === 'FAIVRI_WATCH_LIST') {
    apiRequest('/api/v1/extension/listing-watch', { method: 'GET' }).then(sendResponse)
    return true
  }

  if (msg.type === 'FAIVRI_WATCH_CANCEL') {
    const { watchId } = msg
    if (!watchId) {
      sendResponse({ ok: false, status: 400, error: 'Missing watchId.' })
      return false
    }
    apiRequest(
      `/api/v1/extension/listing-watch/${encodeURIComponent(watchId)}`,
      { method: 'DELETE' },
    ).then(sendResponse)
    return true
  }
})
