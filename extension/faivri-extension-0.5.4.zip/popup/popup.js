const DEFAULT_API_URL = 'https://faircheck-backend-production.up.railway.app'

const apiUrlInput = document.getElementById('apiUrl')
const saveBtn = document.getElementById('saveBtn')
const status = document.getElementById('saveStatus')

chrome.storage.sync.get(['apiUrl']).then(({ apiUrl }) => {
  apiUrlInput.value = apiUrl || DEFAULT_API_URL
}).catch(() => {
  apiUrlInput.value = DEFAULT_API_URL
})

saveBtn.addEventListener('click', async () => {
  const raw = apiUrlInput.value.trim()
  const url = raw || DEFAULT_API_URL
  try {
    // Validate — throws on bad URL.
    const parsed = new URL(url)
    if (!/^https?:$/.test(parsed.protocol)) throw new Error('protocol')
    await chrome.storage.sync.set({ apiUrl: url })
    status.textContent = 'Saved. New setting applies to the next price check.'
    status.classList.remove('err')
  } catch {
    status.textContent = 'That is not a valid URL. Example: https://faircheck-backend-production.up.railway.app'
    status.classList.add('err')
  }
})
